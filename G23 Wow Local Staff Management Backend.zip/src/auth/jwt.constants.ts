export const jwtConstants = {
  secret: 'secretKey',
  expiresIn: '1800s',
};
