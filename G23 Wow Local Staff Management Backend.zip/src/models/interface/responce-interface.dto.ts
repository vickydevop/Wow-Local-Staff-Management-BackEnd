export default interface ResponseInterface {
  message?: string;
  statusCode?: number;
  data?: any;
}
