import { Injectable } from '@nestjs/common';

@Injectable()
export class QP_UploadFileMaster {
  async onUploadFileMaster() {
    try {
    } catch (error) {
      throw error;
    }
  }
}
